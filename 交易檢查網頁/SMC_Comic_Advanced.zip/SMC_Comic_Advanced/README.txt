SMC 白爛貓漫畫進場檢查器 — 進階漫畫板塊版

使用方式：
1. 解壓縮。
2. 保持 index.html 與 assets 資料夾在同一層。
3. 直接雙擊 index.html。
4. 可離線使用。
5. 設定儲存在瀏覽器 LocalStorage。

本版視覺改造：
- 1~8 每個流程都增加獨立漫畫場景
- 每個板塊有專屬主題色、對話框、行情示意圖、角色
- 多週期 / Session / Liquidity / BOS/CHoCH / FVG / Premium-Discount / Risk 都有對應漫畫
- 評分區改成大型漫畫結果板
- 原評分邏輯、儲存、重設功能保留
